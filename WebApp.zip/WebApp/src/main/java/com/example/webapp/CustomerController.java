package com.example.webapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;

@Controller
public class CustomerController {
	private final CustomerRepository customerrepository;

	@Autowired
	public CustomerController(CustomerRepository customerrepository) {
		this.customerrepository = customerrepository;
	}

	@GetMapping("/new")
	public String showSignUpForm(Customer customer) {
		return "add-customer";
	}

	@GetMapping("/edit/{id}")
	public String showUpdateForm(@PathVariable("id") Long id, Model model) {
		Customer customer = customerrepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalid id" + id));
		model.addAttribute("customer", customer);
		return "update-customer";
	}

	@GetMapping("/delete/{id}")
	public String deleteCustomer(@PathVariable("id") Long id, Model model) {
		Customer customer = customerrepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("invalid id" + id));
		customerrepository.delete(customer);
		model.addAttribute("customers", customerrepository.findAll());
		return "index";
	}

	@PostMapping("/addCustomer")
	public String addUser(@Valid Customer customer, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "add-customer";
		}
		customerrepository.save(customer);
		model.addAttribute("customers", customerrepository.findAll());
		return "index";
	}

	@PostMapping("/update/{id}")
	public String updateUser(@PathVariable("id") Long id, @Valid Customer customer, BindingResult result,  Model model) {
		if (result.hasErrors()) {
			customer.setId(id);
			return "update-customer";
		}
		
		customerrepository.save(customer);
		model.addAttribute("customers", customerrepository.findAll());

		return "index";
	}

}
