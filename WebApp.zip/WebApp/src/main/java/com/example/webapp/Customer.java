package com.example.webapp;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity(name="Customer")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
	@Column(name="name")
	@NotBlank(message="name is required")
	private String name;
	@Column(name="surname")
	@NotBlank(message="surname is required")
	private String surname;
	@Column(name="email")
	@NotBlank(message="email is required")
	private String email;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", surname=" + surname + ", email=" + email + "]";
	}
}
