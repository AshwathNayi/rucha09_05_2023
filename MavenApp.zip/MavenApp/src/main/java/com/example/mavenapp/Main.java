package com.example.mavenapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
@SpringBootApplication

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         ApplicationContext con=SpringApplication.run(Main.class, args);
//         ApplicationContext con1=new AnnotationConfigApplicationContext(Config.class);
     Person person=con.getBean(Person.class);
        person.speak(); 
        person.eat();
         
	}

}
