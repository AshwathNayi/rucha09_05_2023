package com.example.mavenapp.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	@RequestMapping("/Home")
   public String home() 
   {
	   return "hello home";
   }
	@RequestMapping("/Aboutus")
	   public String aboutUs() 
	   {
		   return "hello aboutus";
	   }
}
