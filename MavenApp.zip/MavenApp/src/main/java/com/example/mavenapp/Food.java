package com.example.mavenapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Food 
{
	@Autowired
	
	void recipe() 
	{
		System.out.println("recipe is ready");
	}

}
