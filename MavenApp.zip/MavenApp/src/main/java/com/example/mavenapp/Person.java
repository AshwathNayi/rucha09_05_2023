package com.example.mavenapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//import org.springframework.beans.factory.annotation.Autowired;
@Component
public class Person 
{
	
	Food food;
	
	
	void eat() 
	{
		food.recipe();
	}
	void speak() 
	{
			System.out.println("I can speak");
	}

}
