package com.example.springbootapp;

import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class IndexController {
	@RequestMapping("/index")
	public String index() 
	{
		return "index";
	}
	
	//one approach to send data
	//from client to server or server to client
//	@RequestMapping("/result")
//	public String index(HttpServletRequest req) 
//	{
//		 int a=Integer.parseInt(req.getParameter("data"));
//		 System.out.println(a);
//         HttpSession session=req.getSession();
//         session.setAttribute("value", a);
//		return "result";
//	}
//another approach
//	@RequestMapping("/result")
//	public String index(@RequestParam("val")String data,HttpSession session) 
//	{
//		session.setAttribute("value", data);
//		return "result";
//	}
	
	//using model object
//	@RequestMapping("/result")
//	public String index(@RequestParam("val")String data,Model model) 
//	{
//		model.addAttribute("v", data);
//		return "result";
//	}
	//2nd way using model
	/*@RequestMapping("/result")
	public ModelAndView index(String data) 
    {		Map<String,String> map=new HashMap<String,String>();
		map.put("value", data);
		return new ModelAndView("result",map);
    }*/
	
	//3rd approach using mvc
	
/*@RequestMapping("/result")	
public ModelAndView index(String data) 
{
ModelAndView mv=new ModelAndView();	
mv.addObject("value", data);	
return mv;
}*/

}
