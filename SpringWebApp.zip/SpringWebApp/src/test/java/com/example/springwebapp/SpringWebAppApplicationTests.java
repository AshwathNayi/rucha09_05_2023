package com.example.springwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
