package com.example.springwebapp;

import java.util.Arrays;


import org.springframework.data.annotation.*;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="tbl_reg")
public class UserRegistration
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long UID;
    private String uname;
    private String emailid;
    private String password;
    private byte gender;
    private String[] hobby;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getEmailId() {
		return emailid;
	}
	public void setEmailId(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public byte getGender() {
		return gender;
	}
	public void setGender(byte gender) {
		this.gender = gender;
	}
	public String[] getHobby() {
		return hobby;
	}
	public void setHobby(String[] hobby) {
		this.hobby = hobby;
	}
	@Override
	public String toString() {
		return "UserRegistration [uname=" + uname + ", emailid=" + emailid + ", password=" + password + ", gender="
				+ gender + ", hobby=" + Arrays.toString(hobby) + "]";
	}
	




}
