package com.example.springwebapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.example.springwebapp.dao.UserRepo;

@Controller
public class RegistrationController
{
    @Autowired
	UserRepo repo;
	
	@RequestMapping("/regform")
	public String register() 
	{
		return "Registration";
	}
	@RequestMapping("/operation")
	public ModelAndView operation(Long UID,String ddlflag)
	{
		if(ddlflag.equals("select")) 
		{
			UserRegistration reg=repo.findById(UID).orElse(new UserRegistration());
			return selectRecords(reg);
			
		}else if(ddlflag.equals("delete")) 
		{
			repo.deleteById(UID);
		}else if(ddlflag.equals("update")) 
		{
			UserRegistration reg=repo.findById(UID).orElse(new UserRegistration());
			reg.setUname("updated");
			repo.save(reg);
		}
		else 
		{
			System.out.println(repo.searchRecordByUname("rch"));
		}
		return new ModelAndView("operation");
	}
//	@RequestMapping("/userDetail")
//	public ModelAndView userInfo(UserRegistration reg) 
//	{
//		ModelMap model=new ModelMap();
//		model.addAttribute("uname", reg.getUname());
//		model.addAttribute("emailid", reg.getEmailId());
//		model.addAttribute("gender", reg.getGender()==Integer.parseInt("1")?"Male":"Female");
//		model.addAttribute("hobby", reg.getHobby());
//		ModelAndView mv=new ModelAndView("user-detail");
//		mv.addObject("value",model);
//		return mv;
//	}
	@RequestMapping("/userDetail")
	public String userInfo(UserRegistration reg) 
	{
		repo.save(reg);
		return "operation";
	}
	
	public ModelAndView selectRecords(UserRegistration reg)
	{
		ModelMap map=new ModelMap();
		map.put("uname",reg.getUname());
	//	map.put("email",reg.getEmailId());
		map.put("gender",reg.getGender()==Integer.parseInt("1")?"Male":"Female");
		ModelAndView mv=new ModelAndView("user-detail");
		mv.addObject("value", map);
		return mv;
	}
}
