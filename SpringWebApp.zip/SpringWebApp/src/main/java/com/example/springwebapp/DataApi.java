package com.example.springwebapp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springwebapp.dao.UserRepo;
@RestController
public class DataApi 
{
	@Autowired
	UserRepo repo;
	@RequestMapping("/GetUserDetails")
    public List<UserRegistration> getAllData()
    {
    	return repo.findAll();
    }
	@RequestMapping("/getDataById/{uid}")
	public Optional<UserRegistration> getUserById(@PathVariable("uid") Long id){
	    return repo.findById(id);	
	}

}
